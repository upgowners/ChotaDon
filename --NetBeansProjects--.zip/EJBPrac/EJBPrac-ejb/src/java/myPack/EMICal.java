/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myPack;

import javax.ejb.Stateful;

/**
 *
 * @author ankit
 */
@Stateful
public class EMICal implements EMICalLocal {

    @Override
    public String SimpleInt(String prin, String roi, String years) {
        Double pri = Double.parseDouble(prin);
        Double ri = Double.parseDouble(roi);
        Double ye = Double.parseDouble(years);
        
        return (pri*( (ri/100) * ye) + "");
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
