/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myPack;

import java.util.Vector;
import javax.ejb.Stateful;

/**
 *
 * @author ankit
 */
@Stateful
public class CartBean implements CartBeanLocal {
    public Vector<Product> cart = new Vector<Product>();
    
    @Override
    public String addToCart(String pid, String name, String price) {
        
        for (Product product : cart) {
            if(product.getPid().equals(pid)){
             return "product already in cart";   
            }
        }
        Product pr = new Product(pid,name,price);
        cart.add(pr);
        
        return "Product added succesfully";
    }

    @Override
    public String showCart() {
        String all_product = "";
        for (Product product : cart) {
            all_product += product.getPid() + ":" + product.getName()+":"+product.getPrice() + "|";
        }
        return all_product;
    }
}

class Product
{
    String pid;
    String name;
    String price;

    public Product(String pid, String name, String price) {
        this.pid = pid;
        this.name = name;
        this.price = price;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
    
    
}